# プロジェクト?の作成
- 以下のコマンドでディレクトリにプロジェクト?を作りその中でパッケージとアプリを運用できる
  - npm init -y
  - npm install electron --save-dev

# アプリの実行
- package.json を以下の記述を追加
```
{
    "name": "myapp",
    "version": "1.0.0",
    "description": "",
    "main": "index.js",
    "scripts": {
        "start":"electron index.js",
        "test": "echo \"Error: no test specified\" && exit 1"
    },
    "keywords": [],
    "author": "",
    "license": "ISC",
    "devDependencies": {
        "electron": "^6.0.9"
    }
}
```
- "script" → "start" に実行コマンドを
- npm start で実行可能

# htmlから呼ぶjsにnodeの記述を含ませる場合
- index.jsに以下の記述を追加
```
    settingsWindow = new BrowserWindow(
        {webPreferences: { nodeIntegration: true }, // これ
        …
```

# マウスイベントなどの扱い
- window.addEventListener('click', function(){});でやる

# ffiのrequireが通らない件
- nodeのバージョン管理システムを導入
  - git clone git://github.com/creationix/nvm.git ~/.nvm
- ~/.(hoge)shrcに以下の記述
  - source ~/.nvm/nvm.sh
- node 10.2.1を入れる

```
nvm ls-remote
nvm install v10.2.1
nvm use v10.2.1
```

- electronインストール
  - 色々バージョンがある模様
  
```
npm install --save-dev electron@3.1.1 spectron@5.0.0 electron-rebuild electron-packager@12.1.0
```

- node-ffi関連ライブラリを入れる

```
npm install --save natives bindings debug ffi ms nan ref ref-struct
```

- ffi 関連ライブラリのビルド
  - ./node_modules/.bin/electron-rebuild
 
