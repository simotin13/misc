const ipc = require('electron').ipcRenderer
ipc.on('read-done', function (event, arg) {
    document.getElementById("result").value = arg
})
let btnRead = document.getElementById('btn_read')
btnRead.onclick = function()
{
    let file = document.getElementById('file_select')
    ipc.send('read', file.files[0].path)
}

/* エラーになるのでとりあえずFFIはコメントアウト
   Uncaught Error: The module '/home/miyazaki/elctron_app/node_modules/ref/build/R
   elease/binding.node'
   was compiled against a different Node.js version using
   NODE_MODULE_VERSION 64. This version of Node.js requires
   NODE_MODULE_VERSION 73. Please try re-compiling or re-installing
   the module (for instance, using `npm rebuild` or `npm install`).
*/
const ffi = require('ffi');
const StructType = require('ref-struct');
const ref = require('ref');
let btnFfi = document.getElementById('btn_ffi');

var PERSON = StructType({
    //'name': ref.types.char[128],
    'age': ref.types.int,
    'my_number': ref.types.int
});

var ptr_PERSON = ref.refType(PERSON);
var PERSON_val = new PERSON;
btnRead.onclick = function()
{
    const libfactorial = ffi.Library('./funcs.so',{
        'hello':['void',[]], //返り値と引数の型を指定
        'getPerson':['void', [ptr_PERSON]]
    });
    console.log(libfactorial.hello());
    libfactorial.getPerson(PERSON_val.ref());
    var res = PERSON_val.ref();
    console.log(res);
}

