package com.example.setting;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.SpannableStringBuilder;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> _users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setScreenMain();
    }

    private void setScreenMain() {
        setContentView(R.layout.activity_main);
        Button btn = findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("", "onClick");
                setScreenSub();
            }
        });
    }
    private void setScreenSub() {
        setContentView(R.layout.activity_sub);

        loadSetting();

        Button btn = findViewById(R.id.btnSub);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("", "onClick");
                saveSetting();
                setScreenMain();
            }
        });
        Button btnAdd = findViewById(R.id.btnAdd);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO アラートダイアログで入力したユーザを追加
                final EditText editText = new EditText(v.getContext());
                new AlertDialog.Builder(v.getContext())
                        .setTitle("ユーザ追加")
                        .setView(editText)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // OK
                                String user = editText.getText().toString();
                                _users.add(user);

                                // スピナーの表示を更新
                                Spinner spinner = findViewById(R.id.users);
                                String[] users = (String [])_users.toArray();
                                ArrayAdapter<String> adapter = new ArrayAdapter<String>(v.getContext(), android.R.layout.simple_spinner_item, users);
                                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                spinner.setAdapter(adapter);
                            }
                        })
                        .show();
            }
        });
        Button btnDelete = findViewById(R.id.btnDelete);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 選択したユーザを削除

                // 選択されているアイテムのIndexを取得
                Spinner spinner = findViewById(R.id.users);
                int idx = spinner.getSelectedItemPosition();
                _users.remove(idx);

                // スピナーの表示を更新
                String [] users = (String [])_users.toArray();
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(v.getContext(), android.R.layout.simple_spinner_item, users);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner.setAdapter(adapter);
            }
        });

    }

    private void loadSetting() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        String url = prefs.getString("URL", "192.168.1.1");

        EditText view = findViewById(R.id.txtURL);
        view.setText(url);

        // ArrayAdapter
        String userList = prefs.getString("USERS", "user1");
        String [] users = userList.split(",");
        _users = new ArrayList<>();
        for(int i = 0; i < users.length; i++) {
            _users.add(users[i]);
        }

        Spinner spinner = findViewById(R.id.users);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, users);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    private void saveSetting(){
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = prefs.edit();

        EditText txtURL = findViewById(R.id.txtURL);
        SpannableStringBuilder sb = (SpannableStringBuilder)txtURL.getText();
        String url = sb.toString();
        editor.putString("URL", url).commit();

        // 選択されているアイテムのIndexを取得
        Spinner spinner = findViewById(R.id.users);
        int idx = spinner.getSelectedItemPosition();

        // 選択されているアイテムを取得
        String user = (String)spinner.getSelectedItem();
        editor.putString("SELECTED_USER", user).commit();

        // リストを保存
        String users = "";
        int length = _users.size();
        for (int i = 0; i < length; i++) {
            if (i != 0) {
                 users += ",";
            }
            users += _users.get(i);
        }
        editor.putString("USERS", users).commit();
    }
}